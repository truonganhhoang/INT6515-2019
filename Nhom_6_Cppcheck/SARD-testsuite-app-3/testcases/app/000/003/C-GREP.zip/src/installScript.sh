#Check two see if two files are identical.
exactMatch(){
	created="$1"
	expected="$SS_TC_ROOT/testOutput/$2"
	a=$(md5sum $created | awk '{ print $1 }')
	b=$(md5sum $expected | awk '{ print $1 }')
	
	[ "$a" = "$b" ] && echo  "$created: Exact Match" || echo "$created: Not Exact Match"
}

#Checks a file to see if a string is present in the file
contains()
{
	string=$1
	file=$2
	if grep -q "$string" "$file"; 
	then
   		echo "$file ($string): Found"
   	else
   		echo "$file ($string): Not Found"
 	fi
}

# Presents a yes/no option to the user
function confirm() {
    while true; do
        read -p "$1 [y/n] " yn
        case $yn in
            [Yy] | [Yy][Ee][Ss] )
                echo "y"
                break
                ;;
            [Nn] | [Nn][Oo] )
                echo "n"
                break
                ;;
        esac
    done
}

#Determines if the error code in a file is the expected code for a seg fault
segFaults()
{
	file=$1
	if grep -q '134\|136\|139' $SS_TC_ROOT/testData/$file; then
		echo 'Seg Faulted: Yes'
	else
		echo 'Seg Faulted: No'
	fi
}

#Determines from lsb_release if this is a Scientific Linux box and runs returns 0 for true
isSciLinux()
{
	if lsb_release -a | grep -q 'Scientific'; then
		return 0
	else
		return 1
	fi
}
####################################################################
# SCRIPT
####################################################################
cd "$SCRIPTPATH/.."
SS_TC_ROOT="$PWD"
SS_TC_INSTALL="install"
SS_TC_SRC=src
SS_TC_BUILT=built
SS_OS_SPECIFIC_CFLAGS='-fno-stack-protector -z execstack -m32'
echo "*********************************"
echo "Program Name: $progName"
echo "*********************************"
echo ""
echo ""
echo "Dependencies: $SS_TC_DEPS"
echo ""
echo ""
echo " ** Environment Variables **"





#Set Environment Variables
if [ -z "$SS_CC" ];
then
	export SS_CC="gcc"
fi

if [ -z "$SS_LNK" ];
then
	export SS_LNK="gcc"	
fi


echo "SS_CC: $SS_CC"

 
echo "SS_LNK: $SS_LNK"

OLDPATH=$PATH
PATH="$SS_TC_ROOT/$SS_TC_INSTALL/bin:$SS_TC_ROOT/$SS_TC_INSTALL/sbin:$SS_TC_DEPS/bin:$SS_TC_DEPS/sbin:$PATH" 
export PATH
echo "PATH: $PATH"

OLDCPPFLAGS=$CPPFLAGS
CPPFLAGS="-I$SS_TC_DEPS/include $SS_OS_SPECIFIC_CFLAGS" 
export CPPFLAGS
echo "CPPFLAGS: $CPPFLAGS"

OLDLDFLAGS=$LDFLAGS
LDFLAGS="-L$SS_TC_DEPS/lib $SS_OS_SPECIFIC_LDFLAGS"
export LDFLAGS
echo "LDFLAGS: $LDFLAGS"

OLDPKG_CONFIG_PATH=$PKG_CONFIG_PATH
PKG_CONFIG_PATH="$SS_TC_DEPS/lib:$SS_TC_DEPS/lib/pkgconfig:$PKG_CONFIG_PATH"
export PKG_CONFIG_PATH
echo "PKG_CONFIG_PATH: $PKG_CONFIG_PATH"

OLDLD_LIBRARY_PATH=$LD_LIBRARY_PATH
LD_LIBRARY_PATH="$SS_TC_DEPS/lib:$LD_LIBRARY_PATH"
export LD_LIBRARY_PATH
echo "LD_LIBRARY_PATH: $LD_LIBRARY_PATH"



# Clean the Directory
rm -rf "$SS_TC_ROOT/$SS_TC_INSTALL/*"

if [[ $(confirm "Run IOPairs for Binary Distro?") == "y" ]];
then
	# Clean install folder
	rm -rf "$SS_TC_ROOT/$SS_TC_INSTALL/*"

	# Copy installed to built
	cp -Rfd built/* $SS_TC_ROOT/$SS_TC_INSTALL/

	# Change Directory to testData
	cd "$SS_TC_ROOT/testData"

	# Run the IOPairs for Built dir
	echo 'Running IO Pairs For Binary Copy.....'
	runIOPairs
	scoreIOPairs
	read -p 'Press Enter to Cleanup IOPairs...' dummy_variable
	cleanupIOPairs
	
	# Change Directory to root
	cd "$SS_TC_ROOT/"
fi

if [[ $(confirm "Build Source?") == "y" ]];
then
	# Change Directory into the src folder
	cd "$SS_TC_ROOT/$SS_TC_SRC/"

	# Run the configurable runBuild function
	runBuild
	
	if [[ $(confirm "Run IOPairs for Source Distro?") == "y" ]];
	then
		# Change Directory to testData
		cd "$SS_TC_ROOT/testData"
	
		# Run the IOPairs for install dir
		echo 'Running IO Pairs For Source Installation.....'
		runIOPairs
		scoreIOPairs

		read -p 'Press Enter to Cleanup IOPairs...' dummy_variable
		cleanupIOPairs
	fi
		# Change Directory to root
		cd "$SS_TC_ROOT/"
		
	if [[ $(confirm "Replace Binary Copy with Just Built Copy?") == "y" ]];
	then
		# Clean install folder
		rm -rf built/*

		# Copy installed to built
		cp -Rfd $SS_TC_ROOT/$SS_TC_INSTALL/* built/
	fi
fi


#Cleanup install directory
rm -rf "$SS_TC_ROOT/$SS_TC_INSTALL/*"

#Reset Environment Variables
PATH=$OLDPATH
export PATH

CPPFLAGS=$OLDCPPFLAGS
export CPPFLAGS

LDFLAGS=$OLDLDFLAGS
export LDFLAGS

PKG_CONFIG_PATH=$OLDPKG_CONFIG_PATH
export PKG_CONFIG_PATH

LD_LIBRARY_PATH=$OLDLD_LIBRARY_PATH
export LD_LIBRARY_PATH





