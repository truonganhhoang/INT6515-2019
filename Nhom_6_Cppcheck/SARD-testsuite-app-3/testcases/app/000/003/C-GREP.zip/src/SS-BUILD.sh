
# GREP - Setup and Build

# Variable Declarations
progName="grep-2.14"
downloadURL="http://ftp.gnu.org/gnu/grep/grep-2.14.tar.xz"

runBuild() {
		
	./configure --prefix="$SS_TC_ROOT/$SS_TC_INSTALL" --exec-prefix="$SS_TC_ROOT/$SS_TC_INSTALL" --with-included-regex
    	echo ""
    	echo ""
	make CC="$SS_CC" CCLD="$SS_LNK"  install
}

runIOPairs() {

	echo "*********************************"
	echo 'Good - 01'
	echo "*********************************"
	echo 'Running'
	mkdir -p good-01
    $SS_TC_ROOT/$SS_TC_INSTALL/bin/grep ^[ex] input/dict.txt 1> good-01/std-out.txt 2> good-01/std-err.txt
	echo 'Done'
	
	echo "*********************************"
	echo 'Good - 02'
	echo "*********************************"
	echo 'Running'
	mkdir -p good-02
	$SS_TC_ROOT/$SS_TC_INSTALL/bin/grep -r -i BIRMINGHAM input/zip/ | sort  1> good-02/std-out.txt 2> good-02/std-err.txt
	echo 'Done'
	
	echo "*********************************"
	echo 'Good - 03'
	echo "*********************************"
	echo 'Running'
	mkdir -p good-03
    $SS_TC_ROOT/$SS_TC_INSTALL/bin/grep -E -f input/grep-good-03-expr.txt input/mktsymbols.txt 1> good-03/std-out.txt 2> good-03/std-err.txt
	echo 'Done'
	
	echo "*********************************"
	echo 'Good - 04'
	echo "*********************************"
	echo 'Running'
	mkdir -p good-04
    $SS_TC_ROOT/$SS_TC_INSTALL/bin/grep -w '^[A-Za-z].*X\b.*\(AMERICAN\)' input/mktsymbols.txt 1> good-04/std-out.txt 2> good-04/std-err.txt
	echo 'Done'
	
	echo "*********************************"
	echo 'Good - 05'
	echo "*********************************"
	echo 'Running'
	mkdir -p good-05
    $SS_TC_ROOT/$SS_TC_INSTALL/bin/grep --mmap NASDAQ input/mktsymbols.txt 1> good-05/std-out.txt 2> good-05/std-err.txt
	echo 'Done'
	
	echo "*********************************"
	echo 'Good - 06'
	echo "*********************************"
	echo 'Running'
	mkdir -p good-06
   	$SS_TC_ROOT/$SS_TC_INSTALL/bin/grep -v -i -c NASDAQ input/mktsymbols.txt 1> good-06/std-out.txt 2> good-06/std-err.txt
	echo 'Done'
	
	
	echo "*********************************"
	echo 'Good - 07'
	echo "*********************************"
	echo 'Running'
	mkdir -p good-07
    $SS_TC_ROOT/$SS_TC_INSTALL/bin/grep -D read -e ^[DPZ] /dev/stdin < input/mktsymbols.txt 1> good-07/std-out.txt 2> good-07/std-err.txt
	echo 'Done'
	
	
	echo "*********************************"
	echo 'Good - 08'
	echo "*********************************"
	echo 'Running'
	mkdir -p good-08
    $SS_TC_ROOT/$SS_TC_INSTALL/bin/grep -E -C 15 ^[BRT] input/mktsymbols.txt 1> good-08/std-out.txt 2> good-08/std-err.txt
	echo 'Done'
	
	
	echo "*********************************"
	echo 'Good - 09'
	echo "*********************************"
	echo 'Running'
	mkdir -p good-09
   	$SS_TC_ROOT/$SS_TC_INSTALL/bin/grep -v ^[BRT] input/mktsymbols.txt 1> good-09/std-out.txt 2> good-09/std-err.txt
	echo 'Done'


	
	echo "*********************************"
	echo 'Good - 10'
	echo "*********************************"
	echo 'Running'
	mkdir -p good-10
	$SS_TC_ROOT/$SS_TC_INSTALL/bin/grep -c -v ^[BRT] input/mktsymbols.txt 1> good-10/std-out.txt 2> good-10/std-err.txt
	echo 'Done'
	
}

scoreIOPairs(){
	echo "*********************************"
	echo 'Good - 01'
	echo "*********************************"
	exactMatch good-01/std-out.txt good-01/std-out.txt
	echo "*********************************"
	echo 'Good - 02'
	echo "*********************************"
	exactMatch good-02/std-out.txt good-02/std-out.txt
	echo "*********************************"
	echo 'Good - 03'
	echo "*********************************"
	exactMatch good-03/std-out.txt good-03/std-out.txt
	echo "*********************************"
	echo 'Good - 04'
	echo "*********************************"
	exactMatch good-04/std-out.txt good-04/std-out.txt
	echo "*********************************"
	echo 'Good - 05'
	echo "*********************************"
	exactMatch good-05/std-out.txt good-05/std-out.txt
	echo "*********************************"
	echo 'Good - 06'
	echo "*********************************"
	exactMatch good-06/std-out.txt good-06/std-out.txt
	echo "*********************************"
	echo 'Good - 07'
	echo "*********************************"
	exactMatch good-07/std-out.txt good-07/std-out.txt
	echo "*********************************"
	echo 'Good - 08'
	echo "*********************************"
	exactMatch good-08/std-out.txt good-08/std-out.txt
	echo "*********************************"
	echo 'Good - 09'
	echo "*********************************"
	exactMatch good-09/std-out.txt good-09/std-out.txt
	echo "*********************************"
	echo 'Good - 10'
	echo "*********************************"
	exactMatch good-10/std-out.txt good-10/std-out.txt

}


cleanupIOPairs(){
	echo 'Cleaning Up'
	rm -rf good-01
	rm -rf good-02
	rm -rf good-03
	rm -rf good-04
	rm -rf good-05
	rm -rf good-06
	rm -rf good-07
	rm -rf good-08
	rm -rf good-09
	rm -rf good-10
}

#IMPORT the Install Script
SCRIPTPATH="$(dirname "$(readlink -f "$0")")"  
. "$SCRIPTPATH/installScript.sh"
