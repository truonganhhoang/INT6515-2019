This is a simple, gui based sudoku game which includes:
- a sudoku solver which is using an optimized backtracking algorithm to test the solutions.
- a sudoku generator which produces sudoku puzzle using matrix transformations of standard sudoku puzzle.
- three difficulty levels based on time given to solve the puzzle.
- uses a simple swing toolkit based gui.
